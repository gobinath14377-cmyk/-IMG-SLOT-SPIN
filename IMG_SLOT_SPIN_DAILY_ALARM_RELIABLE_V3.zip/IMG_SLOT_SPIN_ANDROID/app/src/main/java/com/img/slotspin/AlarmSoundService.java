package com.img.slotspin;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;

public class AlarmSoundService extends Service {
    private MediaPlayer player;
    private static final String CHANNEL = "img_slot_spin_alarm_v2";
    private static final int NOTIFY = 902;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "IMG SLOT SPIN Alarm", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Daily IMG SLOT SPIN alarm");
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Intent stopIntent = new Intent(this, AlarmStopReceiver.class);
        PendingIntent stopPi = PendingIntent.getBroadcast(this, 903, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, AlarmActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 904, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification notification = builder
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("IMG SLOT SPIN – தினசரி அலாரம்")
                .setContentText("அலாரம் ஒலிக்கிறது. நிறுத்து பட்டனை அழுத்தினால் மட்டுமே நிற்கும்.")
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(openPi)
                .setFullScreenIntent(openPi, true)
                .addAction(android.R.drawable.ic_media_pause, "நிறுத்து", stopPi)
                .build();

        startForeground(NOTIFY, notification);
        try {
            AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audio != null) {
                int max = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                audio.setStreamVolume(AudioManager.STREAM_ALARM, max, 0);
            }
            if (player == null) {
                player = MediaPlayer.create(this, R.raw.alarm_sound);
                if (player != null) {
                    if (Build.VERSION.SDK_INT >= 21) {
                        player.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build());
                    } else {
                        player.setAudioStreamType(AudioManager.STREAM_ALARM);
                    }
                    player.setLooping(true);
                    player.start();
                }
            }
        } catch (Exception ignored) { }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); player.release(); } catch (Exception ignored) { }
            player = null;
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
