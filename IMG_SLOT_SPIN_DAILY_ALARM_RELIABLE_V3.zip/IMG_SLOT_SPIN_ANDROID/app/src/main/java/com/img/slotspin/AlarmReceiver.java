package com.img.slotspin;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        android.content.SharedPreferences prefs = context.getSharedPreferences("daily_alarm", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("enabled", false)) return;

        // Schedule tomorrow's occurrence immediately so the alarm repeats every day.
        AlarmScheduler.schedule(context, prefs.getInt("hour", 9), prefs.getInt("minute", 0));

        Intent service = new Intent(context, AlarmSoundService.class);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
        else context.startService(service);
    }
}
