# IMG SLOT SPIN – Full-screen daily alarm update

Includes the latest HTML UI and native Android daily alarm. The alarm uses AlarmManager, the supplied MP3, a foreground playback service, and a full-screen alarm activity intent for a locked screen.

On first use, grant Notifications, Alarms & reminders (exact alarm), and Full-screen notifications / full-screen intent if shown. Some Android manufacturers also require enabling background activity/autostart and excluding battery optimization. Android, DND, manufacturer settings, or force-stop can still prevent a full-screen launch; the notification is the fallback. Force-stopping the app can stop future alarms until it is opened again.

Upload/replace the repository files with this ZIP contents and run the existing GitHub Actions Build APK workflow.
