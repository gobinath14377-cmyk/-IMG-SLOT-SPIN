IMG SLOT SPIN – Android Project (GitHub Actions APK Build)

மொபைலில் GitHub வழியாக APK உருவாக்க:
1. இந்த ZIP-ஐ போனில் பதிவிறக்கி Extract செய்யவும்.
2. github.com-ல் Sign in செய்து New repository உருவாக்கவும்.
3. Repository-ல் Add file → Upload files மூலம் ZIP-ஐ Extract செய்த கோப்புகள் அனைத்தையும் upload செய்யவும்.
4. Commit changes அழுத்தவும்.
5. மேலே Actions tab திறக்கவும்.
6. Build IMG SLOT SPIN APK workflow தேர்வு செய்து Run workflow அழுத்தவும்.
7. Build முடிந்ததும் workflow run-ஐத் திறந்து Artifacts பகுதியில் IMG-SLOT-SPIN-APK பதிவிறக்கவும்.
8. பதிவிறக்கிய ZIP-ஐ Extract செய்து app-debug.apk-ஐ Android போனில் திறந்து Install செய்யவும்.

குறிப்பு:
- Workflow கோப்பு ஏற்கெனவே .github/workflows/build-apk.yml-ல் சேர்க்கப்பட்டுள்ளது.
- GitHub Actions cloud runner-ல் Gradle build நடக்கும்; போனில் Android Studio தேவையில்லை.
- இது Debug APK. தனிப்பட்ட release signing key இல்லாமல் வெளியீட்டு APK அல்ல.
