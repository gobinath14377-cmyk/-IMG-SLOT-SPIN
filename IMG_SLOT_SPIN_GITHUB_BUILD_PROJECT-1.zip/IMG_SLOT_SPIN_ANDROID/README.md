# IMG SLOT SPIN — Android Project

## Included
- IMG SLOT SPIN V7 HTML app bundled locally in Android WebView
- Launcher icon artwork
- Java Android entry activity
- Local browser storage enabled for saved numbers and history

## Build APK with Android Studio
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio → Open → choose the `IMG_SLOT_SPIN_ANDROID` folder.
4. Wait for Gradle sync and Android SDK 35 installation if prompted.
5. Build → Build Bundle(s) / APK(s) → Build APK(s).
6. Android Studio will show the APK location. Usually:
   `app/build/outputs/apk/debug/app-debug.apk`

## App details
- App name: IMG SLOT SPIN
- Package: com.img.slotspin
- Version: 1.0
- Minimum Android: 6.0 (API 23)

This is an Android Studio source project, not a compiled APK.
