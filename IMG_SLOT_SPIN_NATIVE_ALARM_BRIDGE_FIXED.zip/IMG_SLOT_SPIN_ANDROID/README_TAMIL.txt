IMG SLOT SPIN – Native Daily Alarm Update

இந்த ZIP-ல் உள்ள Android project-ஐ GitHub-க்கு upload செய்து GitHub Actions மூலம் APK build செய்யலாம்.

புதிய வசதிகள்:
- தினசரி அலாரம்: நீங்கள் தேர்வு செய்யும் நேரத்தில் Android AlarmManager மூலம் இயங்கும்.
- அனுப்பிய AUD-20250603-WA0001.mp3 சவுண்ட் அலாரமாக இணைக்கப்பட்டுள்ளது.
- அலாரம் ஒலிக்கும் போது Android Alarm Volume அதிகபட்சமாக அமைக்கப்படும்.
- அலாரம் சத்தம் நிற்க notification-ல் உள்ள “நிறுத்து” பொத்தானை அழுத்தவும்.
- போன் restart ஆன பிறகும் சேமித்த அலாரம் மீண்டும் அமைக்கப்படும்.
- தேவையற்ற அறிவுரை / அடுத்த அலாரம் / நிறுவப்பட்டது போன்ற வாசகங்கள் இல்லை.

குறிப்பு:
முதல் முறை அலாரம் ON செய்யும்போது Notifications அனுமதி மற்றும் Android Exact Alarm அனுமதி கேட்கப்படலாம். இரண்டையும் அனுமதிக்கவும். Phone Settings-ல் app-க்கு Battery restriction இருந்தால் Unrestricted/Allow background activity அமைக்கவும். App-ஐ Force stop செய்தால் Android அலாரத்தை இயக்காது; மீண்டும் app திறந்த பிறகு அலாரம் அமைப்பை ON செய்யவும்.
