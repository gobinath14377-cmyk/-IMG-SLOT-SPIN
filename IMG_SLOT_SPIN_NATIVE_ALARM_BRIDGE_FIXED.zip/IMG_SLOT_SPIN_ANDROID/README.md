# IMG SLOT SPIN – Native Daily Alarm Bridge Fix

This version fixes a missing connection between the HTML alarm controls and the Android native alarm service.

- The Save Time button sends the selected time to Android when alarm is ON.
- The ON/OFF button schedules or cancels the Android daily alarm.
- AlarmReceiver starts the foreground alarm sound service and schedules the next day.
- The bundled MP3 is used for the alarm sound.
- Exact alarms and notifications must be allowed in Android settings.
- Full-screen alarm UI depends on Android's Full-screen intent permission and manufacturer policy.
- Force-stopping the app prevents scheduled alarms until the app is opened again.

## Testing
Set a test time at least 2–3 minutes in the future. Tap Save Time. Toggle OFF then ON if needed. Grant Alarms & reminders / exact alarm access, Notifications, and Full-screen notifications if offered. Lock the screen and wait.
