package com.img.slotspin;
import android.app.*; import android.content.*; import android.os.Build;
import java.util.Calendar;
public class AlarmScheduler {
 static PendingIntent pending(Context c){return PendingIntent.getBroadcast(c,901,new Intent(c,AlarmReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 public static void cancel(Context c){((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pending(c));}
 public static void schedule(Context c,int hour,int minute){
  Calendar t=Calendar.getInstance(); t.set(Calendar.HOUR_OF_DAY,hour);t.set(Calendar.MINUTE,minute);t.set(Calendar.SECOND,0);t.set(Calendar.MILLISECOND,0);
  if(t.getTimeInMillis()<=System.currentTimeMillis())t.add(Calendar.DAY_OF_YEAR,1);
  AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  try {
   if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pending(c));
   else am.setExact(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pending(c));
  } catch (SecurityException denied) {
   // Exact-alarm access must be enabled in Android settings before scheduling.
  }
 }
}
