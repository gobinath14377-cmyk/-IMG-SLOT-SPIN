package com.img.slotspin;
import android.content.*;
public class AlarmStopReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){c.stopService(new Intent(c,AlarmSoundService.class));} }
