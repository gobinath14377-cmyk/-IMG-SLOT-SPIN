package com.img.slotspin;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 44;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,13,29));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,13,29));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(8,13,29));
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new AlarmBridge(this), "AndroidAlarm");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }

    public class AlarmBridge {
        private final Context context;
        AlarmBridge(Context c){context=c;}
        @JavascriptInterface public void setDailyAlarm(String time){
            try {
                String[] p=time.split(":"); int hour=Integer.parseInt(p[0]), minute=Integer.parseInt(p[1]);
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager manager=(AlarmManager)getSystemService(ALARM_SERVICE);
                    if (!manager.canScheduleExactAlarms()) {
                        runOnUiThread(() -> {
                            try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); }
                            catch(Exception ignored) {}
                        });
                        return;
                    }
                }
                getSharedPreferences("daily_alarm",MODE_PRIVATE).edit().putInt("hour",hour).putInt("minute",minute).putBoolean("enabled",true).apply();
                AlarmScheduler.schedule(context,hour,minute);
            } catch(Exception ignored) {}
        }
        @JavascriptInterface public void cancelAlarm(){
            getSharedPreferences("daily_alarm",MODE_PRIVATE).edit().putBoolean("enabled",false).apply();
            AlarmScheduler.cancel(context);
        }
        @JavascriptInterface public void stopAlarm(){context.stopService(new Intent(context,AlarmSoundService.class));}
        @JavascriptInterface public void requestAlarmPermissions(){
            runOnUiThread(()->{
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION_REQUEST);
                if(Build.VERSION.SDK_INT>=31){ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
                    if(!am.canScheduleExactAlarms()){ try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception ignored){} }
                }
                if(Build.VERSION.SDK_INT>=34){ try { if(!getSystemService(android.app.NotificationManager.class).canUseFullScreenIntent()) startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:"+getPackageName()))); } catch(Exception ignored){} }
            });
        }
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
