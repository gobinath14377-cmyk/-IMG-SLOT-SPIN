package com.img.slotspin;
import android.app.*;import android.content.*;import android.media.*;import android.os.*;
public class AlarmSoundService extends Service {
 private MediaPlayer player; private static final String CHANNEL="img_slot_spin_alarm"; private static final int NOTIFY=902;
 @Override public void onCreate(){super.onCreate();createChannel();}
 private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"IMG SLOT SPIN Alarm",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Daily alarm");ch.enableVibration(true);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  Intent stop=new Intent(this,AlarmStopReceiver.class);PendingIntent stopPi=PendingIntent.getBroadcast(this,903,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
  Intent full=new Intent(this,AlarmActivity.class); full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); PendingIntent fullPi=PendingIntent.getActivity(this,904,full,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=b.setFullScreenIntent(fullPi,true).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("IMG SLOT SPIN").setContentText("⏰").setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"நிறுத்து",stopPi).build();
  startForeground(NOTIFY,n);
  try{AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);int max=am.getStreamMaxVolume(AudioManager.STREAM_ALARM);am.setStreamVolume(AudioManager.STREAM_ALARM,max,0);
   if(player==null){player=MediaPlayer.create(this,R.raw.alarm_sound);if(player!=null){player.setAudioStreamType(AudioManager.STREAM_ALARM);player.setLooping(true);player.start();}}
  }catch(Exception ignored){}
  return START_STICKY;
 }
 @Override public void onDestroy(){if(player!=null){try{if(player.isPlaying())player.stop();player.release();}catch(Exception ignored){}player=null;}stopForeground(true);super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
