package com.img.slotspin;
import android.content.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())){android.content.SharedPreferences p=c.getSharedPreferences("daily_alarm",Context.MODE_PRIVATE);if(p.getBoolean("enabled",false))AlarmScheduler.schedule(c,p.getInt("hour",9),p.getInt("minute",0));}} }
