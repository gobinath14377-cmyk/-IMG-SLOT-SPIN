package com.img.slotspin;
import android.content.*;
public class AlarmReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  android.content.SharedPreferences p=c.getSharedPreferences("daily_alarm",Context.MODE_PRIVATE);
  if(!p.getBoolean("enabled",false))return;
  Intent service=new Intent(c,AlarmSoundService.class);
  if(android.os.Build.VERSION.SDK_INT>=26)c.startForegroundService(service);else c.startService(service);
  AlarmScheduler.schedule(c,p.getInt("hour",9),p.getInt("minute",0));
 }
}
