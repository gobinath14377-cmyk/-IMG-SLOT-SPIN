package com.img.slotspin;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;

public class AlarmActivity extends Activity {
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeText(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(true);
        return view;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().setStatusBarColor(Color.rgb(8, 19, 41));
        getWindow().setNavigationBarColor(Color.rgb(8, 19, 41));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        root.setBackgroundColor(Color.rgb(8, 19, 41));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(20));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.rgb(7, 21, 43));
        cardBg.setCornerRadius(dp(24));
        cardBg.setStroke(dp(1), Color.rgb(42, 62, 91));
        card.setBackground(cardBg);

        TextView first = makeText("வெற்றி நமதே!", 34, Color.rgb(255, 216, 77));
        first.setShadowLayer(dp(10), 0, 0, Color.rgb(255, 190, 45));
        first.setPadding(0, 0, 0, dp(5));

        TextView second = makeText("வெற்றி நிச்சயம்", 31, Color.WHITE);
        second.setPadding(0, 0, 0, dp(5));

        TextView third = makeText("இது வேத சத்தியம்!", 31, Color.rgb(255, 216, 77));
        third.setShadowLayer(dp(8), 0, 0, Color.rgb(255, 190, 45));
        third.setPadding(0, 0, 0, dp(20));

        android.view.View divider = new android.view.View(this);
        divider.setBackgroundColor(Color.rgb(75, 91, 116));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        dividerParams.setMargins(0, dp(2), 0, dp(18));

        TextView title = makeText("IMG SLOT SPIN", 30, Color.rgb(255, 218, 92));
        title.setShadowLayer(dp(5), 0, 0, Color.rgb(255, 190, 45));

        TextView alarm = makeText("⏰ தினசரி அலாரம்", 23, Color.WHITE);
        alarm.setPadding(0, dp(18), 0, dp(22));

        Button stop = new Button(this);
        stop.setText("🔕 அலாரத்தை நிறுத்து");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, AlarmSoundService.class));
            finish();
        });

        card.addView(first);
        card.addView(second);
        card.addView(third);
        card.addView(divider, dividerParams);
        card.addView(title);
        card.addView(alarm);
        root.addView(card, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        stopParams.setMargins(0, dp(22), 0, 0);
        root.addView(stop, stopParams);
        setContentView(root);
    }

    @Override
    public void onBackPressed() { }
}
